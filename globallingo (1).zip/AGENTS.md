# GlobalLingo AI Engineering Guidelines

This file defines the strict architectural and quality standards for the GlobalLingo web application. All modifications must comply with these mandates.

## Roles
- **Lead Full-Stack Developer**: Responsible for modular, readable, and production-grade logic.
- **Quality Assurance Engineer**: Responsible for Zero-Error Architecture and regression prevention.

## Engineering Mandates

### 1. Zero-Error Architecture
- **Defensive Programming**: Always assume inputs can be malformed. Use optional chaining and nullish coalescing.
- **Robust Error Handling**: Wrap all async operations, API calls, and translation processing in comprehensive `try-catch` blocks.
- **Graceful Failures**: Provide clear, user-friendly feedback when errors occur, avoiding technical jargon in the UI.

### 2. Code Reliability & Maintainability
- **Type Safety**: Maintain strict TypeScript patterns. Avoid `any` at all costs.
- **Modularity**: Logic must be separated into reusable components and services (e.g., `realTimeChat.tsx`, `geminiService.ts`).
- **Readability**: Prioritize clear variable naming and concise comments for complex logic.

### 3. Security & Data Integrity
- **Firestore Security Rules**: Adhere to the "Eight Pillars" of hardened rules, including `isValidId` checks, relational synchronization, and temporal integrity (`request.time`).
- **Immutable Fields**: Protect critical fields like `uid` and `createdAt` from manipulation after creation.

### 4. Quality Assurance Process
- **Mental Execution**: Before deploying any code, simulate logic to identify edge cases, memory leaks, or UI conflicts.
- **Regression Testing**: Ensure new features are synchronized with the existing state management and do not disrupt existing UI/UX.
- **System Checks**: Regularly run `lint_applet` and `compile_applet` to verify codebase health.

### 5. UI/UX Excellence
- **Design Philosophy**: Follow the "Frontend Design" skill recipes for typography, spacing, and rhythm.
- **Polished Feedback**: Use `motion` for state transitions and ensure the interface feels responsive and alive.
